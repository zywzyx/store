

def IABC(moneyy, transferCode):
    from nicetry import takemoneyww
    y = moneyy
    x = int(transferCode)
    takemoneyww(x, y)

def ABC(a, c):
    from test import takemoneyee
    account2 = a
    tranmoney = c
    takemoneyee(account2, tranmoney)
